import React from "react";


export const EventInvoke = () => {

    const [count, setCount] = React.useState(0);

    const countIncrease = () => {
        setCount(prevState => prevState + 1)
    }
    const countDecrease = () => {
        setCount(prevState => prevState - 1)
    }

    const sayHello = () => {
        alert("Hello")
    }

    const clickEvent = () => {
        alert("I was clicked!")
    }


    return (
        <React.Fragment>
            <div>
                <p>{count}</p>
                <button onClick={countIncrease}>Increase</button>
                <button onClick={countDecrease}>Decrease</button>
            </div>
            <div>
                <button onClick={sayHello}>Say Hello</button>
            </div>
            <div>
                <button onClick={clickEvent}>Click me</button>
            </div>
        </React.Fragment>
    )
}