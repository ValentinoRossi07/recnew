import logo from './logo.svg';
import './App.css';
import {EventInvoke} from "./EventInvoke";
import {CurrencyConvetor} from "./CurrencyConvetor";

function App() {
    return (
        <div className="App">
            <EventInvoke/>
            <CurrencyConvetor/>
        </div>
    );
}

export default App;
