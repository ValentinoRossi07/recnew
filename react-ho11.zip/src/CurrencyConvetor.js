import React from "react";


export const CurrencyConvetor = () => {

    const [amount, setAmount] = React.useState(0);
    const [currency, setCurrency] = React.useState({
        currencyCode: ''
    });

    const evaluate = () => {
        currency.currencyCode.toLowerCase() === "euro" ? alert(`Converter Amount is ${(amount * 82.71).toFixed(2)}`) : alert()
    }

    return (
        <React.Fragment>
            <h1>Currency Convertor</h1>

            <table>
                <tbody>
                <tr>
                    <td>
                        Amount
                    </td>
                    <td>
                        <input type="text" name="amount" id="amount" value={amount}
                               onChange={(e) => setAmount(e.target.value)}/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Currency
                    </td>
                    <td>
                        <input type="text" name="currencyCode" id="currencyCode" value={currency.currencyCode}
                               onChange={(e) => setCurrency(prevState => ({
                                   ...prevState,
                                   [e.target.name]: e.target.value
                               }))}/>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" onClick={evaluate} value="Submit"/>
                    </td>
                </tr>
                </tbody>
            </table>
        </React.Fragment>
    )
}