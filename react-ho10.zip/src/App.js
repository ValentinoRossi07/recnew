import React from "react";

import Image from "./image.jpg"

function App() {
    const element = "Office Space";
    const imgTag = <img src={Image} width="200" height="200" alt="Office Space"/>

    const officeData = {
        Name: "DBS",
        Rent: 50000,
        Address: "Chennai"
    }

    const color = officeData.Rent <= 60000 ? "red" : "green"

    return (
        <div className="App">
            <h1>{element}, at Affordable Range</h1>
            {imgTag}
            <h1>Name: {officeData.Name}</h1>
            <h1 style={{color}}>Rent: {officeData.Rent}</h1>
            <h1>Address: {officeData.Address}</h1>
        </div>
    );
}

export default App;
