import Styles from './EmployeeCard.module.css';
import {useContext} from "react";
import {ThemeContext} from "./ThemeContext";

function EmployeeCard(props) {
    const data = useContext(ThemeContext)
    console.log(data)
    return (
        <div className={Styles.Card}>
            <h3>{props.employee.name}</h3>
            <p>{props.employee.email}</p>
            <p>{props.employee.phone}</p>
            <p>
                <a className={data}>Edit</a>
                <a className={data}>Delete</a>
            </p>
        </div>
    );
}

export default EmployeeCard;

