import React from "react";
import './App.css';

const GuestGreeting = ({handleClick}) => {
    return (
        <React.Fragment>
            <div>
                <h4>Please sign up</h4>
                <button onClick={handleClick}>Login</button>
            </div>
        </React.Fragment>
    )
}
const UserGreeting = ({handleClickLogout}) => {
    return (
        <React.Fragment>
            <div>
                <h4>Welcome Back</h4>
                <button onClick={handleClickLogout}>Logout</button>
            </div>
        </React.Fragment>
    )
}


function App() {

    const [isLoggedIn, setIsLoggedIn] = React.useState(false);

    const handleClickLogout = () => {
        setIsLoggedIn(false)
    }
    const handleClickLogin = () => {
        setIsLoggedIn(true)
    }

    return (
        <div className="App">
            {!isLoggedIn ?
                <GuestGreeting handleClick={handleClickLogin}/> :
                <UserGreeting handleClickLogout={handleClickLogout}/>
            }
        </div>
    );
}

export default App;
