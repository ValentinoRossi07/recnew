import React from "react";


export const Blog = ({book, blog, course}) => {

    const bookDetail = (
        <ul>
            {book.map((e, index) => (
                <div key={e.id}>
                    <h3>{e.bname}</h3>
                    <h4>{e.price}</h4>
                </div>
            ))}
        </ul>
    );

    const courseDetail = (
        <ul>
            {course.map((e) => (
                <div key={e.id}>
                    <h3>{e.name}</h3>
                    <h4>{e.date}</h4>
                </div>
            ))}
        </ul>
    );

    const blogDetail = (
        <ul>
            {blog.map((e) => (
                <div key={e.id}>
                    <h3>{e.blogName}</h3>
                    <h4>{e.pname}</h4>
                    <p>{e.para}</p>
                </div>
            ))}
        </ul>
    )


    return (
        <React.Fragment>
            <table className="table">
                <tr>
                    <div>
                        <td>
                            <div className="mystyle1">
                                <h1 className="tableheader">Course Details</h1>
                                {courseDetail}
                            </div>
                        </td>
                        <td className="tin">
                            <div className="st2">
                                <h1 className="tableheader">Book Details</h1>
                                {bookDetail}
                            </div>
                        </td>
                        <td>
                            <div className="v1">
                                <h1 className="tableheader">Blog Details</h1>
                                {blogDetail}
                            </div>
                        </td>
                    </div>
                </tr>
            </table>

        </React.Fragment>
    )
}