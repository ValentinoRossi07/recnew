import './App.css';

import {books, BlogDetails, CourseDetail} from "./Books"
import {Blog} from "./Blog";


function App() {
    return (
        <div className="App">
            <Blog book={books} blog={BlogDetails} course={CourseDetail}/>
        </div>
    );
}

export default App;
