const books = [
    {id: 101, bname: 'Master React', price: 670},
    {id: 102, bname: 'Deep Dive into Angular 11', price: 800},
    {id: 103, bname: 'Mongo Essentials', price: 450}
]
const BlogDetails = [
    {id: 201, blogName: 'React Learning', pname: 'Stephan Biz', para: 'Welcome to Learning React!'},
    {id: 202, blogName: 'Installation', pname: 'Schewzdenier', para: 'You can install React from npm'}
]
const CourseDetail = [
    {id: 301, name: 'Angular', date: '4/5/2021'},
    {id: 302, name: 'React', date: '6/3/2021'}
]
export {books, BlogDetails, CourseDetail};